/* PersonCfg geometry: CfgExtension.GetUrlParm/GetBubblePos, RoleMgr.GetRoleL2dParm. */
(()=>{'use strict';
const esc=StudentAgeCharacterUI.esc,copy=v=>structuredClone(v);
function effectiveMode(p,grade,mode,gender=1){return mode==='live'&&!p?.[grade?'l2d2':'l2d']?.[p.id===0&&gender===2?1:0]?'static':mode;}
function geometry(p,grade,mode,gender=1){
 mode=effectiveMode(p,grade,mode,gender);
 const female=p.id===0&&gender===2,index=female?1:0;
 const young=mode==='live'?grade===0:(grade===0?!!p.url?.length:!p.url2?.length);
 const key=(mode==='live'?'l2dParm':'urlParm')+(young?'':'2'),offset=female?3:0;
 const row=mode==='live'?p[key]?.[index]:p[key]?.slice(offset,offset+3);
 return {key,index,offset,scale:Number(row?.[mode==='live'?0:2]??(mode==='live'?1500:1)),x:Number(row?.[mode==='live'?1:0]??0),y:Number(row?.[mode==='live'?2:1]??0),flip:mode==='live'&&row?.[3]===1};
}
function writeGeometry(p,grade,mode,gender,value){
 mode=effectiveMode(p,grade,mode,gender);
 const g=geometry(p,grade,mode,gender),row=mode==='live'?[value.scale,value.x,value.y,value.flip?1:0]:[value.x,value.y,value.scale];
 if(!row.every(Number.isFinite)||!(value.scale>0))throw Error('大小必须大于零，位置需要是有效数字。');
 if(mode==='live'){p[g.key]=copy(p[g.key]||[]);while(p[g.key].length<=g.index)p[g.key].push([1500,0,0,0]);p[g.key][g.index]=[...row,...p[g.key][g.index].slice(4)];}
 else{const arr=copy(p[g.key]||[]);while(arr.length<g.offset+3)arr.push(arr.length%3===2?1:0);arr.splice(g.offset,3,...row);p[g.key]=arr;}
}
// Match the visible bounds in native game units; retain each image's aspect ratio.
function linkedGeometry(p,grade,gender,mode,value,metrics){
 writeGeometry(p,grade,mode,gender,value);
 if(!metrics?.size?.[1]||!metrics?.bounds?.[3]||effectiveMode(p,grade,'live',gender)!=='live')return;
 const [bx,by,bw,bh]=metrics.bounds,H=metrics.size[1];
 if(mode==='static'){
  const old=geometry(p,grade,'live',gender),scale=H*value.scale/bh;
  writeGeometry(p,grade,'live',gender,{...old,scale,x:value.x-(old.flip?-1:1)*(bx+bw/2)*scale,y:50+value.y-H*value.scale/2-by*scale});
 }else{
  const height=bh*value.scale;
  writeGeometry(p,grade,'static',gender,{scale:height/H,x:value.x+(value.flip?-1:1)*(bx+bw/2)*value.scale,y:value.y+by*value.scale+height/2-50});
 }
}
function bubbleKey(p,grade){if(grade===0){if(p.url?.length)return 'bubbleParm';if(p.url2?.length)return 'bubbleParm2';return 'bubbleParm';}if(p.url2?.length)return 'bubbleParm2';if(p.url?.length)return 'bubbleParm';return p.bubbleParm2?.length?'bubbleParm2':'bubbleParm';}
function writeBubble(p,grade,gender,height){if(!Number.isFinite(height))throw Error('气泡高度无效。');const key=bubbleKey(p,grade),idx=p.id===0&&gender===2?1:0;const arr=copy(p[key]||[]);while(arr.length<=idx)arr.push(StudentAgeScene.bubbleY(p,grade,false));arr[idx]=height;p[key]=arr;}
function referenceRows(rows,grade,mode='live'){const key=mode==='live'?(grade?'l2d2':'l2d'):(grade?'url2':'url');return Object.values(rows).flatMap(p=>{const paths=mode==='live'?(p[key]?.length?p[key]:(p[grade?'url2':'url']?.length?p[grade?'url2':'url']:p[grade?'url':'url2'])):(p[key]?.length?p[key]:p[grade?'url':'url2']);return p.id===0?[1,2].filter(g=>paths?.[g-1]).map(g=>({person:p,gender:g,label:g===1?'男主 · 白雨':'女主 · 白雨'})):paths?.[0]?[{person:p,gender:p.gender,label:p.name}]:[];});}
// Frozen native model frames use the same bounds/parameters as dialogue preview.
// No real-time model renderer is created by this page.
function modelSource(p,grade,gender,rows){
 const key=grade?'l2d2':'l2d',index=p?.id===0&&gender===2?1:0,name=p?.[key]?.[index];
 if(!name)return null;
 const source=rows?.[p.id]?.[key]?.[index]===name?p:Object.values(rows||{}).find(r=>r[key]?.includes(name));
 if(!source)return null;
 return {role:source.id,gender:source.id===0&&source[key].indexOf(name)===1?2:1};
}
function comparisonScale(stages){
 const ready=stages.filter(s=>s.ready);if(!ready.length)return 0;
 return Math.min(...ready.map(s=>(s.node.clientHeight-60)/Math.max(...ready.map(t=>t.size[1]))),...ready.map(s=>(s.node.clientWidth-60)/Math.max(...ready.map(t=>t.size[0]))));
}
function create(ctx){const {S,host,person,change,options,imageURL,readonly}=ctx;
 const V={kind:'portrait',mode:'static',gender:1,reference:105,referenceGender:2,emoji:11};let epoch=0,resize=null,stages=[],dialogs=new Set(),timer=null,dead=false,drag=null;
 const adjustable=()=>StudentAgeCharacterImages.kinds.find(k=>k.id===V.kind)?.adjust;
 const q=s=>host.querySelector(s),native=()=>S.data?.tables.PersonCfg.referenceRows||{};
 const atlas='/api/social-emojis?'+new URLSearchParams({token:options.token});
 const talkUi={manifest:'/api/talk-ui?'+new URLSearchParams({token:options.token}),resource:name=>'/api/talk-ui?'+new URLSearchParams({resource:name,token:options.token})};
 function writeOwn(mode,value){writeGeometry(person(),S.grade,mode,V.gender,value);}
 function stop(){epoch++;dead=true;resize?.disconnect();resize=null;clearTimeout(timer);timer=null;drag=null;for(const s of stages){clearTimeout(s.timer);clearTimeout(s.linkTimer);if(s.request)window.STUDIO_CACHE_TASKS?.finish('model:'+JSON.stringify(s.request));s.live?.destroy();if(s.renderer){s.renderer.disposed=true;StudentAgeScene.releaseBubbleAssets(s.renderer.bubbleReady);}const img=s.node.querySelector('img');if(img){img.onload=null;img.onerror=null;}}stages=[];for(const d of dialogs){d.close();d.remove();}dialogs.clear();}
 function modal(title,html,handler){const d=document.createElement('dialog');d.className='social-dialog model-picker';d.setAttribute('data-dismiss-outside','');d.innerHTML=`<header><h2>${title}</h2><button data-model-close>关闭</button></header>${html}`;document.body.append(d);dialogs.add(d);const close=()=>{d.close();d.remove();dialogs.delete(d);};d.onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-model-close'))close();else handler(b,close,d);};d.oncancel=e=>{e.preventDefault();close();};d.showModal();return d;}
 async function chooseReference(){
 const selected=S.selected,grade=S.grade,rows=referenceRows(native(),grade,V.mode).map(r=>({...r.person,id:r.person.id+':'+r.gender,recordId:r.person.id,gender:r.gender,name:r.label,source:'original'}));
 const row=await STUDIO_ASSET_PICKER.pickRecords('portrait',{title:'选择原版人物参考',rows,projectId:options.project.id,selected:V.reference+':'+V.referenceGender,image:r=>'/api/space-head?'+new URLSearchParams({projectId:options.project.id,personId:r.recordId,gender:r.gender,token:options.token})});
 if(row&&S.selected===selected&&S.grade===grade){V.reference=row.recordId;V.referenceGender=row.gender;render();}
 }

 function chooseEmoji(){modal('选择参考气泡的 emoji',`<div class="social-emoji-grid">${StudentAgeSocialMedia.glyphs.map((_,i)=>`<button data-model-emoji="${i}" aria-label="表情 ${i}">${StudentAgeSocialMedia.renderText('<sprite='+i+'>',atlas)}</button>`).join('')}</div>`,(b,close)=>{if(b.dataset.modelEmoji!==undefined){V.emoji=Number(b.dataset.modelEmoji);close();paintAll();}});}
 function render(){stop();dead=false;const p=person();if(!p)return;V.mode=adjustable()&&modelSource(p,S.grade,V.gender,native())?'live':'static';host.classList.add('character-model-mode');const form=q('#character-form');q('#character-preview').innerHTML='';
 const refs=referenceRows(native(),S.grade,'static');let ref=refs.find(r=>r.person.id===V.reference&&r.gender===V.referenceGender);if(!ref){ref=refs.find(r=>r.person.id===105)||refs[0];if(ref){V.reference=ref.person.id;V.referenceGender=ref.gender;}}
 form.innerHTML=`<div class="model-heading"><div><h2>人物图片与大小</h2><p>立绘按游戏实际尺寸对照；头像按相同显示框对照。</p></div><div class="model-switches"><div>${[0,1].map(g=>`<button data-model-grade="${g}" aria-pressed="${S.grade===g}">${g?'中学':'小学'}</button>`).join('')}</div><label>图片类型<select data-model-kind>${StudentAgeCharacterImages.kinds.map(k=>`<option value="${k.id}" ${V.kind===k.id?'selected':''}>${k.name}</option>`).join('')}</select></label><button data-model-image ${readonly()?'disabled':''}>选择图片</button>${p.id===0?`<div><button data-model-gender="1" aria-pressed="${V.gender===1}">男主</button><button data-model-gender="2" aria-pressed="${V.gender===2}">女主</button></div>`:''}</div></div><div class="model-comparison">${[{p,label:p.name,editable:true,gender:V.gender,mode:V.mode},{p:ref?.person,label:ref?.label||'没有可用的参考',editable:false,gender:V.referenceGender,mode:'static'}].map(r=>`<section class="model-card"><header><strong>${esc(r.label)}</strong>${r.editable?'<span>正在编辑</span>':'<button data-model-reference>更换参考</button>'}</header><div class="model-stage" data-model-stage="${r.editable?'own':'reference'}"><div class="model-origin"></div><div class="model-art" ${r.editable?'data-model-drag="move"':''}><img draggable="false" alt="${esc(r.label)}">${r.editable?'<button class="model-size-handle" data-model-drag="size" aria-label="拖动调整人物大小">↗</button>':''}</div><div class="scene-actor-emoji" ${r.editable?'data-model-drag="bubble" title="上下拖动调整气泡高度"':''}></div><p class="model-load-status" role="status">正在读取…</p></div></section>`).join('')}</div><div class="model-tools"><button data-model-emoji-open>选择气泡 emoji</button><span>静态朝向由剧情动作控制，本页保持原版方向</span></div><div class="model-values">${[['scale','大小'],['x','左右偏移'],['y','上下偏移'],['bubble','气泡高度']].map(([k,l])=>`<label>${l}<input data-model-value="${k}" aria-label="${l}" type="range" min="${k==='scale'?0.01:-2400}" max="${k==='scale'?5:2400}" step="${k==='scale'?0.01:1}" ${readonly()?'disabled':''}><output data-model-output="${k}"></output></label>`).join('')}</div><p class="helper">拖动人物移动，拖动右上角手柄缩放，滚轮也可缩放；拖动当前人物的气泡调整高度。气泡与 emoji 保持原版尺寸，所选 emoji 仅用于对照，不会写入剧情。原版模型使用静态截图，保留游戏实际大小，不实时渲染。</p><p class="helper">拍照用图片是游戏拍照界面中「表情选择按钮」的小图；实际合影仍使用人物立绘或 Live2D。未填写时，原版会回退到人物头像。</p>`;
 stages=[{node:q('[data-model-stage="own"]'),p,gender:V.gender,mode:V.mode,editable:!readonly()},{node:q('[data-model-stage="reference"]'),p:ref?.person,gender:V.referenceGender,mode:adjustable()&&modelSource(ref?.person,S.grade,V.referenceGender,native())?'live':'static',editable:false}];const stamp=epoch;for(const s of stages){s.editable=s.editable&&adjustable();s.node.classList.toggle('model-booth',V.kind==='booth');s.node.querySelectorAll('[data-model-drag]').forEach(n=>{if(!adjustable())n.removeAttribute('data-model-drag');});s.node.querySelector('.model-size-handle')?.toggleAttribute('hidden',!adjustable());loadArt(s,stamp);}q('.model-values').hidden=!adjustable();q('.model-tools').hidden=!adjustable();resize=new ResizeObserver(paintAll);stages.forEach(s=>resize.observe(s.node));bind();values();paintAll();}
 async function loadArt(s,stamp){if(!s.p){s.settled=true;s.node.querySelector('[role=status]').textContent='没有可用的静态参考立绘';return;}const p=s.p,img=s.node.querySelector('.model-art img'),status=s.node.querySelector('[role=status]');s.ready=false;s.settled=false;
 s.mode=effectiveMode(p,S.grade,s.mode,s.gender);
 try{
 if(s.mode==='live'){
  const source=modelSource(p,S.grade,s.gender,native());
  const info=await options.api('/api/portraits',{projectId:options.project.id,...source,grade:S.grade,cloth:s===stages[0]?S.cloth||0:0,face:s===stages[0]?S.previewFace||0:0});
  if(stamp!==epoch)return;
  const bounds=info.frame?.bounds;
  if(!Array.isArray(bounds)||bounds.length!==4||!bounds.every(Number.isFinite)||bounds[2]<=0||bounds[3]<=0||!info.available?.length){
   if(info.active){status.textContent='正在读取游戏人物参照…';s.timer=setTimeout(()=>loadArt(s,stamp),1000);return;}
   throw Error('游戏人物参照尚未就绪，请点击重试。');
  }
  s.bounds=bounds;
  const face=s===stages[0]?S.previewFace||0:0,cloth=s===stages[0]?S.cloth||0:0;
  s.path=`portrait-cache/${source.role===0&&source.gender===2?'0-female':source.role}-${S.grade}-${cloth}-${info.available.includes(face)?face:info.available.includes(0)?0:info.available[0]}.png`;
  img.onload=()=>{if(stamp!==epoch)return;s.size=[img.naturalWidth,img.naturalHeight];s.ready=true;s.settled=true;status.textContent='';paintAll();};
  img.onerror=()=>fail(Error('游戏人物参照读取失败，请点击重试。'));img.src=imageURL(s.path);return;
 }
 const path=StudentAgeCharacterImages.path(p,V.kind,S.grade,s.gender,s===stages[0]?ctx.all('ModFaceCfg'):S.data?.tables.ModFaceCfg?.referenceRows,s===stages[0]?ctx.all('KZoneAvatarCfg'):S.data?.tables.KZoneAvatarCfg?.referenceRows,s===stages[0]?S.cloth:0,s===stages[0]?S.previewFace:0);if(!path)throw Error('尚未设置这类图片，请选择图片。');s.path=path;
 if(!StudentAgeScene.portraitSizes.has(s.path)||/^(Mods|Textures|StudentAgeStudio)[\\/]/i.test(s.path)){const sizes=await options.api('/api/portrait-dimensions',{projectId:options.project.id,paths:[s.path]});if(stamp!==epoch)return;for(const [key,size]of Object.entries(sizes))StudentAgeScene.portraitSizes.set(key,size);}
 img.onload=()=>{if(stamp!==epoch)return;s.size=StudentAgeScene.staticPortraitSize(img,s.path);s.ready=true;s.settled=true;status.textContent='';paintAll();};img.onerror=()=>fail(Error('静态图片读取失败，请点击重试。'));img.src=imageURL(s.path);
 }catch(e){fail(e);}function fail(e){if(stamp!==epoch)return;s.settled=true;status.textContent=e.message;status.onclick=()=>loadArt(s,stamp);paintAll();}}
 function paint(s){if(dead||!s.p||!s.node.isConnected)return;const node=s.node,H=node.clientHeight,W=node.clientWidth,u=H/2400,g=s.draft||geometry(s.p,S.grade,s.mode,s.gender),art=node.querySelector('.model-art');let box;
 if(stages.some(t=>!t.settled)){art.style.visibility='hidden';node.querySelector('.scene-actor-emoji').hidden=true;if(s.ready)node.querySelector('[role=status]').textContent='正在读取另一侧参照…';return;}
 if(s.ready){node.querySelector('[role=status]').textContent='';node.querySelector('.scene-actor-emoji').hidden=false;if(!adjustable()){const slot=['head','comicHead','photoButton','avatar'].includes(V.kind),u=slot?Math.min(W-60,H-60)/Math.max(...s.size):comparisonScale(stages);Object.assign(art.style,{left:(W-s.size[0]*u)/2+'px',top:(H-s.size[1]*u)/2+'px',width:s.size[0]*u+'px',height:s.size[1]*u+'px',visibility:'visible'});node.querySelector('.scene-actor-emoji').hidden=true;return;}if(s.mode==='live'){const [x,y,w,h]=s.bounds;box={x:g.x+(g.flip?-1:1)*(x+w/2)*g.scale,y:g.y+y*g.scale,w:w*g.scale,h:h*g.scale};}else{box={x:g.x,y:50+g.y-s.size[1]*g.scale/2,w:s.size[0]*g.scale,h:s.size[1]*g.scale};}Object.assign(art.style,{left:(W/2+(box.x-box.w/2)*u)+'px',top:((1400-box.y-box.h)*u)+'px',width:box.w*u+'px',height:box.h*u+'px',visibility:'visible'});art.querySelector('img').style.transform=`scaleX(${g.flip?-1:1})`;s.live?.resize();}
 const bubblePerson=s.bubbleDraft===undefined?s.p:copy(s.p);if(s.bubbleDraft!==undefined)writeBubble(bubblePerson,S.grade,s.gender,s.bubbleDraft);
 s.renderer??={options:{talkUi},artBox:()=>({x:0,bottom:-1000,width:W/u,height:2400}),drawVersion:0,drawOptions:{animate:false},state:true,refreshPortraits:paintAll};s.renderer.artBox=()=>({x:0,bottom:-1000,width:W/u,height:2400});s.renderer.doc={persons:{[s.p.id]:bubblePerson},protagonistGender:s.gender};
 // Reuse the production native bubble layout and TMP sprite metrics.
 const role={id:s.p.id,grade:S.grade,emoji:V.emoji};if(s.p.id===0)s.renderer.doc.playerGender=s.gender;
 StudentAgeScene.Renderer.prototype.positionEmoji.call(s.renderer,node,role);
 }
 function paintAll(){if(dead)return;for(const s of stages)paint(s);}
 function values(){const p=person(),g=geometry(p,S.grade,V.mode,V.gender);for(const [k,v]of Object.entries({...g,bubble:StudentAgeScene.bubbleY(p,S.grade,p.id===0&&V.gender===2)})){const el=q('[data-model-value="'+k+'"]');if(el){if(k==='scale'){const live=effectiveMode(p,S.grade,V.mode,V.gender)==='live';el.min=live?1:.01;el.max=live?5000:5;el.step=live?1:.01;}el.min=Math.min(Number(el.min),v);el.max=Math.max(Number(el.max),v);el.value=v;const output=q('[data-model-output="'+k+'"]');if(output)output.textContent=String(Math.round(v*10000)/10000);}}}
 function bind(){const root=q('#character-form');root.onchange=e=>{if(e.target.dataset.modelKind!==undefined){V.kind=e.target.value;render();}};root.onclick=async e=>{const b=e.target.closest('button');if(!b||b.disabled)return;if(b.hasAttribute('data-model-image')){try{await StudentAgeCharacterImages.select(ctx,V.kind,V.gender);render();}catch(error){options.status?.(error.message,true);}return;}if(b.dataset.modelGrade!==undefined){S.grade=Number(b.dataset.modelGrade);render();}else if(b.dataset.modelMode){V.mode=b.dataset.modelMode;render();}else if(b.dataset.modelGender){V.gender=Number(b.dataset.modelGender);render();}else if(b.hasAttribute('data-model-reference'))chooseReference();else if(b.hasAttribute('data-model-emoji-open'))chooseEmoji();else if(b.hasAttribute('data-model-flip')){const g=geometry(person(),S.grade,V.mode,V.gender);change(()=>writeOwn(V.mode,{...g,flip:!g.flip}));paintAll();values();}};
 root.oninput=e=>{const key=e.target.dataset.modelValue;if(!key||readonly())return;const v=Number(e.target.value);if(!e.target.value.trim()||!Number.isFinite(v)||key==='scale'&&v<=0){e.target.setAttribute('aria-invalid','true');return;}e.target.removeAttribute('aria-invalid');change(()=>key==='bubble'?writeBubble(person(),S.grade,V.gender,v):writeOwn(V.mode,{...geometry(person(),S.grade,V.mode,V.gender),[key]:v}),'model:'+S.selected+':'+S.grade+':'+V.mode+':'+key);paintAll();values();};
 const own=stages[0],node=own.node;node.onpointerdown=e=>{const target=e.target.closest('[data-model-drag]');if(!target||!own.editable||!own.ready||stages.some(s=>!s.settled)||e.button!==0)return;e.preventDefault();const g=geometry(person(),S.grade,own.mode,V.gender);drag={kind:target.dataset.modelDrag,x:e.clientX,y:e.clientY,g,height:StudentAgeScene.bubbleY(person(),S.grade,person().id===0&&V.gender===2),u:node.clientHeight/2400};node.setPointerCapture(e.pointerId);};
 node.onpointermove=e=>{if(!drag)return;const dx=(e.clientX-drag.x)/drag.u,dy=-(e.clientY-drag.y)/drag.u;if(drag.kind==='bubble')own.bubbleDraft=drag.height+dy;else own.draft=drag.kind==='size'?{...drag.g,scale:Math.max(.001,drag.g.scale*Math.exp((e.clientX-drag.x-e.clientY+drag.y)/220))}:{...drag.g,x:drag.g.x+dx,y:drag.g.y+dy};paint(own);};
 node.onpointerup=()=>{if(!drag)return;drag=null;if(own.draft){const value=own.draft;change(()=>writeOwn(V.mode,value));}if(own.bubbleDraft!==undefined){const value=own.bubbleDraft;change(()=>writeBubble(person(),S.grade,V.gender,value));}delete own.draft;delete own.bubbleDraft;paintAll();values();};node.onpointercancel=()=>{drag=null;delete own.draft;delete own.bubbleDraft;paintAll();};
 node.onwheel=e=>{if(!own.editable||!own.ready||stages.some(s=>!s.settled)||!e.target.closest('.model-art'))return;e.preventDefault();const g=geometry(person(),S.grade,V.mode,V.gender);change(()=>writeOwn(V.mode,{...g,scale:Math.max(.001,g.scale*Math.exp(-e.deltaY*.001))}),'model-wheel:'+S.selected+':'+S.grade+':'+V.mode);paintAll();values();};}
 return {render,stop,state:V};
}
window.StudentAgeCharacterModel={effectiveMode,create,geometry,writeGeometry,linkedGeometry,bubbleKey,writeBubble,referenceRows,modelSource,comparisonScale};
})();
