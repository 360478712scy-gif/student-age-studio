"""Bounded, local diagnostics. Never let a failed log hide the original error."""
from datetime import datetime, timezone
import os
import json
from pathlib import Path
import platform
import re
import secrets
import threading
import traceback

from game_locator import settings_path
from platform_support import lock_file, unlock_file

APP_VERSION = '1.5.3'

def display_version(value):
    return {'1.4.10-beta.7': '1.4.9.7', '1.4.10-beta.6': '1.4.9.6', '1.4.10-beta.5': '1.4.9.5', '1.4.10-beta.4': '1.4.9.4', '1.4.10-beta.3': '1.4.9.3', '1.4.10-beta.2': '1.4.9.2', '1.4.10-beta.1': '1.4.9.1', '1.4.0': '1.4', '1.3.12-beta.12': '1.3.11.12', '1.3.12-beta.11': '1.3.11.11', '1.3.12-beta.10': '1.3.11.10', '1.3.12-beta.9': '1.3.11.9', '1.3.12-beta.8': '1.3.11.8', '1.3.12-beta.7': '1.3.11.7', '1.3.12-beta.6': '1.3.11.6', '1.3.12-beta.5': '1.3.11.5', '1.3.12-beta.4': '1.3.11.4', '1.3.12-beta.3': '1.3.11.3', '1.3.12-beta.2': '1.3.11.2', '1.3.12-beta.1': '1.3.11.1', '1.3.10-beta.2': '1.3.9.2', '1.3.10-beta.1': '1.3.9.1', '1.3.7-beta.2': '1.3.7.1', '1.3.7-beta.3': '1.3.7.2', '1.3.7-beta.4': '1.3.7.3', '1.3.7-beta.5': '1.3.7.4', '1.3.7-beta.6': '1.3.7.5', '1.3.7-beta.7': '1.3.7.6', '1.3.7-beta.8': '1.3.7.7', '1.3.7-beta.9': '1.3.7.8', '1.3.7-beta.10': '1.3.7.9'}.get(str(value).removeprefix('v'), value)

KEEP = 20
_lock = threading.RLock()
_filename = re.compile(r'error-\d{8}T\d{12}Z-[0-9a-f]{12}\.log\Z')


def redact(text, private=()):
    text = str(text)
    for value in private:
        if value:
            text = text.replace(str(value), '[已隐藏]')
    # Session tokens also occur in media URLs and browser stack traces.
    text = re.sub(r'(https?://[^\s?#\"\'<>]+)[?#][^\s\"\'<>]*', r'\1[参数已隐藏]', text)
    text = re.sub(r'(?i)((?:token|authorization|password|api[_-]?key)\s*[=:]\s*)[^\s,;]+', r'\1[已隐藏]', text)
    return text


class ErrorLogs:
    def __init__(self, root=None):
        self.root = Path(root or os.environ.get('STUDIO_ERROR_LOG_ROOT') or settings_path().parent / 'ErrorLogs').expanduser().resolve()

    def _files(self):
        return sorted(p for p in self.root.iterdir() if _filename.fullmatch(p.name) and p.is_file() and not p.is_symlink())

    def settings(self):
        try:
            value = json.loads((self.root / 'settings.json').read_text(encoding='utf-8'))
            return {'autoCleanup': value.get('autoCleanup') is not False}
        except (OSError, ValueError, AttributeError):
            return {'autoCleanup': True}

    def configure(self, payload):
        value = payload.get('autoCleanup')
        if type(value) is not bool:
            raise ValueError('请选择是否自动清理错误日志。')
        from server import atomic_write, json_bytes
        with _lock:
            self.root.mkdir(parents=True, exist_ok=True)
            with (self.root / '.writer.lock').open('a+b') as guard:
                try:
                    lock_file(guard)
                except BlockingIOError as error:
                    from server import ApiError
                    raise ApiError('另一个窗口正在写入错误日志，请稍后重试。', 409, 'log_busy') from error
                try:
                    atomic_write(self.root / 'settings.json', json_bytes({'autoCleanup':value}))
                    if value: self._prune()
                finally: unlock_file(guard)
        return self.status()

    def slow(self, method, route, waited, ran):
        """One line per request that took over 2 s: how long it queued behind others, and how long it ran itself.
        Kept to the latest ~300 lines, so a report shows which request held up saving."""
        try:
            line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\t{APP_VERSION}\t{method} {route}\t排队 {waited:.1f}s\t执行 {ran:.1f}s\n"
            path = self.root / 'slow-requests.log'
            with _lock:
                self.root.mkdir(parents=True, exist_ok=True)
                lines = path.read_text(encoding='utf-8').splitlines(True) if path.exists() else ['拾光工坊慢请求记录（超过 2 秒的接口：排队时间 = 等待前面的请求，执行时间 = 自身耗时）\n']
                lines = lines[:1] + lines[1:][-299:] + [line]
                path.write_text(''.join(lines), encoding='utf-8')
        except OSError:
            pass

    def stuck(self, method, route, phase, seconds, stack):
        """A request still unfinished after 20 s (the editor looks frozen): what it waits on and where it is."""
        try:
            path = self.root / 'slow-requests.log'
            with _lock:
                self.root.mkdir(parents=True, exist_ok=True)
                lines = path.read_text(encoding='utf-8').splitlines(True) if path.exists() else ['拾光工坊慢请求记录（超过 2 秒的接口：排队时间 = 等待前面的请求，执行时间 = 自身耗时）\n']
                entry = [f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\t{APP_VERSION}\t{method} {route}\t仍未完成 {seconds:.0f}s（{phase}）\n"]
                entry += ['\t\t' + frame + '\n' for frame in stack[-14:]]
                lines = lines[:1] + lines[1:][-(300 - len(entry)):] + entry
                path.write_text(''.join(lines), encoding='utf-8')
        except OSError:
            pass

    def _prune(self):
        for path in self._files()[:-KEEP]:
            try: path.unlink()
            except OSError: pass

    def status(self):
        # Do not create files just because the settings panel was opened.
        try:
            count = len(self._files())
        except OSError:
            count = 0
        return {'path': str(self.root), 'count': count, 'limit': KEEP, **self.settings()}

    def write(self, error=None, *, operation='内部操作', private=(), detail=None):
        try:
            now = datetime.now(timezone.utc)
            name = 'error-' + now.strftime('%Y%m%dT%H%M%S%fZ-') + secrets.token_hex(6) + '.log'
            diagnostic = (''.join(traceback.format_exception(type(error), error, error.__traceback__))
                          if error is not None else str(detail or '未知错误'))
            text = '\n'.join([
                '拾光工坊 · 学生时代模组编辑器 · 错误日志', '软件版本：' + APP_VERSION,
                '时间（UTC）：' + now.isoformat(), '系统：' + platform.platform(),
                'Python：' + platform.python_version(), '操作：' + str(operation), '',
                '错误详情 / 堆栈：', diagnostic,
                '\n日志不包含请求正文、完整模组数据或本地会话令牌。',
            ])
            text = redact(text, private)
            with _lock:
                self.root.mkdir(parents=True, exist_ok=True)
                # Multiple open app versions share this directory and quota.
                with (self.root / '.writer.lock').open('a+b') as guard:
                    owned = True
                    try:
                        lock_file(guard)
                    except BlockingIOError:
                        # Never drop a diagnostic because another window holds the lock:
                        # the file name is unique, so writing beside it stays safe.
                        owned = False
                    try:
                        with (self.root / name).open('x', encoding='utf-8') as output:
                            output.write(text)
                        if self.settings()['autoCleanup']: self._prune()
                    finally:
                        if owned: unlock_file(guard)
            return name
        except Exception:
            return None

    def response(self, error, message, code, operation, private=()):
        name = self.write(error, operation=operation, private=private)
        suffix = (' 错误日志已生成，可在“工坊设置 → 错误日志”查看。' if name else
                  ' 错误日志未能写入，请检查软件数据目录的写入权限或剩余空间。')
        return {'error': message + suffix, 'code': code, 'errorLog': name}
